angular.module('starter.controllers', [])



.controller('DashCtrl', function($scope, $http,$ionicLoading,$ionicPlatform ) {

  $ionicPlatform.ready(function() 
  
  {
    //     function onSuccess(result){ 
    //       alert( $scope.test);   
    // }     
    // function onError(result) {  
    // }
    // window.plugins.CallNumber.callNumber(onSuccess, onError, "9643805583");   


    //
    // window.plugins.flashlight.available(function(isAvailable) {
    //   if (isAvailable) {
     
    //     // switch on
    //     window.plugins.flashlight.switchOn(
    //       function() {}, // optional success callback
    //       function() {}, // optional error callback
    //       {intensity: 0.3} // optional as well
    //     );
     
    //     // switch off after 3 seconds
    //     setTimeout(function() {
    //       window.plugins.flashlight.switchOff(); // success/error callbacks may be passed
    //     }, 3000);
     
    //   } else {
    //     alert("Flashlight not available on this device");
    //   }
    // });
    function OnOffline(){
      alert('Offline')
    }
    function OnOnline(){
      alert('OnOnline')
    };
    document.addEventListener("offline", OnOffline, false);
    document.addEventListener("online", OnOnline, false);
  });
 
$scope.covids=[];
$ionicLoading.show({
  template: '<ion-spinner icon="lines" class="spinner-energized"></ion-spinner>',

}).then(function(){
  
});
  $http.get('https://coronavirus-monitor.p.rapidapi.com/coronavirus/cases_by_country.php', {
    headers: {'X-RapidAPI-Key': 'c1c292d2a3msh03f6e7893df2bafp16b548jsn9685227082ba'}
}).then(function(resposne){
//alert('ok');
$scope.covids=resposne.data.countries_stat;
$ionicLoading.hide();
});
  
})



